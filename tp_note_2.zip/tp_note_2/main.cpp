#include "FileSystem.hpp"
#include "Directory.hpp"
#include "File.hpp"
#include <iostream>

using namespace std;

int main()
{
  FileSystem fs("ramfs");

  // QUELQUES TESTS
  if(fs.get_name() != "ramfs")
    cerr << "Probl�me: le nom de fs n'est pas \"ramfs\"" << endl;
  if(fs.get_root()->get_name() != "root")
    cerr << "Probl�me: le nom du dossier racine n'est pas \"root\"" << endl;
  if(fs.get_root()->find_node("truc") != nullptr)
    cerr << "Probl�me: le dossier racine contient un n�ud" << endl;
  if(fs.get_root()->remove_node("truc") != false)
    cerr << "Probl�me: l'op�ration de suppression de n�ud a r�ussi alors que le dossier est vide" << endl;
  if(fs.get_root()->add_file("truc") == nullptr)
  {
    cerr << "Probl�me: add_file a renvoy� un pointeur nul lors de l'ajout d'un fichier � la racine" << endl;
  }
  else if(fs.get_root()->remove_node("truc") != true)
  {
    cerr << "Probl�me: remove_node a �chou� alors qu'il aurait d� r�ussir" << endl;
  }
  // FIN DES TESTS

  File *temp_file = nullptr;
  Directory *temp_dir = nullptr;

  // CR�ATION D'UN FICHIER AVEC ATTRIBUTION D'UN CONTENU
  temp_file = fs.get_root()->add_file("rootfile");
  temp_file->set_content("This is a file at root.");

  // UN TEST DE find_node
  if((temp_file = fs.get_root()->find_node("rootfile")->to_File()) == nullptr || temp_file->get_name() != "rootfile")
  {
    cerr << "Probl�me: find_node ne trouve pas le bon fichier" << endl;
  }
  // FIN DU TEST

  // UN TEST DU CALCUL DE TAILLE
  if(temp_file->size() != (int)string("This is a file at root.").size())
    cerr << "Probl�me: la taille du fichier n'est pas correctement calcul�e" << endl;
  // FIN DU TEST

  // CR�ATION DE FICHIERS ET DE DOSSIERS
  temp_dir = fs.get_root()->add_Directory("dirA");

  temp_file = temp_dir->add_file("fileAA");
  temp_file->set_content("This is file AA.");

  temp_file = temp_dir->add_file("fileAB");
  temp_file->set_content("This is file AB.");

  temp_dir = fs.get_root()->add_Directory("dirB");

  temp_file = temp_dir->add_file("fileBA");
  temp_file->set_content("This is file BA.");

  temp_file = temp_dir->add_file("fileBB");
  temp_file->set_content("This is file BB.");

  // TESTS DES M�THODES VIRTUELLES DE FILE ET DIRECTORY
  Node *temp_node = temp_file;
  if(temp_node->is_directory())
    cerr << "Probl�me: is_directory() ne renvoie pas la bonne valeur sur un n�ud qui est un fichier" << endl;
  if(temp_node->to_File() == nullptr)
    cerr << "Probl�me: to_file() renvoie un pointeur nul sur un n�ud fichier" << endl;
  if(temp_node->to_directory() != nullptr)
    cerr << "Probl�me: to_directory() renvoie un pointeur non nul sur un n�ud fichier" << endl;
  if(temp_node->size() != (int) 16)
    cerr << "Probl�me: mauvais calcul de la taille d'un fichier" << endl;
  temp_node = temp_dir;
  if(!temp_node->is_directory())
    cerr << "Probl�me: is_directory() ne renvoie pas la bonne valeur sur un n�ud qui est un dossier" << endl;
  if(temp_node->to_File() != nullptr)
    cerr << "Probl�me: to_file() renvoie un pointeur non nul sur un n�ud dossier" << endl;
  if(temp_node->to_directory() == nullptr)
    cerr << "Probl�me: to_directory() renvoie un pointeur nul sur un n�ud fichier" << endl;
  if(temp_node->size() != (int) 32)
    cerr << "Probl�me: mauvais calcul de la taille d'un dossier" << endl;
  // FIN DES TESTS

  // AFFICHAGE
  cout << "Affichage du syst�me de fichiers:" << endl;
  cout << fs << endl;
  // devrait afficher:
  // filesystem "ramfs"
  // + directory: "root", uid: 0, size: 87
  //  + file: "rootfile", uid: 2, size: 23, content: "This is a file at root."
  //  + directory: "dirA", uid: 3, size: 32
  //   + file: "fileAA", uid: 4, size: 16, content: "This is file AA."
  //   + file: "fileAB", uid: 5, size: 16, content: "This is file AB."
  //  + directory: "dirB", uid: 6, size: 32
  //   + file: "fileBA", uid: 7, size: 16, content: "This is file BA."
  //   + file: "fileBB", uid: 8, size: 16, content: "This is file BB."
  // (les uid peuvent �tre diff�rents des v�tres)

  // TESTS DE SUPPRESSION D'UN FICHIER ET D'UN DOSSIER
  if(!fs.get_root()->remove_node("rootfile"))
  {
    cerr << "Probl�me: �chec de la suppression de \"rootfile\"" << endl;
  }
  if(!fs.get_root()->remove_node("dirA"))
  {
    cerr << "Probl�me: �chec de la suppression de \"dirA\"" << endl;
  }
  // FIN DES TESTS

  // AFFICHAGE APR�S SUPPRESSION D'UN FICHIER ET D'UN DOSSIER
  cout << "Affichage apr�s suppression de \"rootfile\" et \"dirA\":" << endl;
  cout << fs;
  // devrait afficher:
  // filesystem "ramfs"
  // + directory: "root", uid: 0, size: 32
  //  + directory: "dirB", uid: 6, size: 32
  //   + file: "fileBA", uid: 7, size: 16, content: "This is file BA."
  //   + file: "fileBB", uid: 8, size: 16, content: "This is file BB."
  // (les uid peuvent �tre diff�rents des v�tres)
  return 0;
}
