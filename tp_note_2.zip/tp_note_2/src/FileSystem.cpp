#include "FileSystem.hpp"
#include "Directory.hpp"
int FileSystem::identifier=0;

FileSystem::FileSystem(const string &_name):name(_name),root(new Directory(this,get_fresh_uid(),"root"))
{
    //uid=get_fresh_uid();
}


 Directory *FileSystem::get_root() const{
    return this->root;
 }


 int FileSystem::get_fresh_uid()
{
    identifier++;
    return identifier;
}

string FileSystem::get_name() const
{
    return name;
}

FileSystem::~FileSystem()
{
    delete root;
}

std::ostream&  operator<<( ostream& out , FileSystem &fs)
{
     string message= "FileSystem : "+ fs.get_name();
      out << message <<endl;

    out << *fs.get_root();


}
