#include "Directory.hpp"
#include "File.hpp"
#include <iostream>
//#include <vector>

//#include "FileSystem.hpp"

Directory::Directory(FileSystem *_fs, const int &_uid, const string &_name ,Directory  *_parent):
     Node(_fs,_uid,_name,_parent)
{

}

Directory::~Directory()
{
   //delete [] children;//impossible par ce que vecteur n'est pas pointeur
   for(int i=0;i<children.size();i++)
       delete children[i];
}
bool Directory::is_directory(){
  return true;
}

Directory  *Directory::to_directory()
{
   return this;
}
File *Directory::to_File()
{
  return nullptr;
}


int Directory::size(){

     int som=0;
    for(int i=0;i<children.size();i++)
        som +=children[i]->size();
    return som;

}


File *Directory::add_file(const string &nomfichier )
{

    for(int i=0;i<children.size();i++)
      if(children[i]->get_name() == nomfichier)
        return nullptr;

      File *f= new File(this->getFileSystem(),FileSystem::get_fresh_uid(),nomfichier,this);
      this->children.push_back(f);

      return f;

}

Directory *Directory::add_Directory(const string &nomdossier)
{

    for(int i=0;i<children.size();i++)
      if(children[i]->get_name() == nomdossier)
        return nullptr;
    Directory *p = new Directory(this->getFileSystem(),FileSystem::get_fresh_uid(),nomdossier,this);

    this->children.push_back(p);

    return p;
}



bool Directory::remove_node(const string &name)
{
   for(int i(0);i<children.size();i++)
    if(children[i]->get_name() == name)
        {
            Node *d=children[i];

            this->children.erase(this->children.begin()+i);

            delete d;

            return true;
        }
   return false;
}

Node  *Directory::find_node(const string &name)
{
    for(int i=0;i<children.size();i++)
     if(children[i]->get_name() == name)
        return children[i];
    return nullptr;
}

void Directory::print_to(ostream & out, const int &n)
{

    string message = "";
       for(int i=0;i<n;i++)
          message+=" ";

       message += "+ Directory : \" "+this->get_name()+" \", uid: "+to_string( this->get_uid() )+" size: "+to_string(this->children.size());
       out << message<<endl;

   for(int i=0;i<children.size();i++)
        children[i]->print_to(out,n+1);

}


ostream& operator <<( ostream& out , Directory &d)
{
      d.print_to(out,2);
}


