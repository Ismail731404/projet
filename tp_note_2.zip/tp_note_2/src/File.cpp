#include "File.hpp"

File::File(FileSystem *_fs,const int &_uid,const string &_name ,Directory  *_parent):
    Node( _fs, _uid,  _name , _parent)
{

}

File::~File()
{

}

bool File::is_directory(){

    return false;
}

Directory  *File::to_directory()
{
     return nullptr;
}
    File *File::to_File()
    {

       return this;
    }


    int File::size(){

           return content.length();
    }

 string File::get_content() const
 {
    return content;
 }


void File::set_content(const string &s)//lors de passe par reference il faut tjr maittre const
{
       content= s;
}

void File::print_to(ostream & out,const int &n)
{
     string message = "";
       for(int i=0;i<n;i++)
          message+="  ";

       message +="+ file : \" "+this->get_name()+"\", uid: "+to_string(this->get_uid())+" size: "+to_string(this->content.size())+" content: "+this->content ;



      out << message<<endl ;

}


