#include "Node.hpp"
#include <string>


Node::Node(FileSystem *_fs,const int &_uid,const string &_name ,Directory *_parent): fs(_fs),uid(_uid),name(_name),parent(_parent)
{

}
string Node::get_name() const
{
   return name;
}

void Node::setName(const string &_name){
     name=_name;
 }
 int Node::get_uid() const
 {
     return uid;
 }

Node::~Node()
{

}
FileSystem *Node::getFileSystem(){
   return fs;
}
