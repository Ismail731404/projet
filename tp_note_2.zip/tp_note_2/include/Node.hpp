class Directory;
class File;
class FileSystem;
#ifndef NODE_HPP
#define NODE_HPP
#include <string>


//#include "Directory.hpp"
class Directory;

using namespace std;

class Node
{
     friend class Directory;
    public:
        string get_name() const;
        void setName(const string &_name);
        virtual bool is_directory()=0;
        virtual Directory *to_directory()=0;
        virtual File *to_File()=0;
        virtual int size()=0;
        FileSystem *getFileSystem();
        int get_uid() const;
        virtual void print_to(ostream & out, const int &n)=0;



    protected:
        Node(FileSystem *_fs,const int &_uid, const string &_name ,Directory  *_parent = nullptr);
        virtual ~Node();


    private:

        FileSystem  *fs;
        int uid;
        string name;
        Directory *parent;
};

#endif // NODE_HPP
