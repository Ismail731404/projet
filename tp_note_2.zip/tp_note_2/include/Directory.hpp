#ifndef DIRECTORY_HPP
#define DIRECTORY_HPP
#include <vector>
#include "FileSystem.hpp"
#include "Node.hpp"
#include <iostream>
using namespace std;

class Directory : public Node {

     friend class FileSystem;
    public:
        bool is_directory();
        Directory *to_directory();
        File *to_File();
        int size();
        vector <Node *> children;
        File *add_file(const string &nomfichier);
        Directory *add_Directory(const string &nomdossier);
        bool remove_node(const string &name);
        Node *find_node(const string &name);
        virtual void print_to(ostream & out, const int &n);

    protected:

    private:
        Directory(FileSystem *_fs,const int &_uid,const string &_name ,Directory  *_parent = nullptr);

        virtual ~Directory();

};

ostream& operator <<( ostream& out , Directory &d);

#endif // DIRECTORY_HPP
