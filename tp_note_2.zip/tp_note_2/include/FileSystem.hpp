#ifndef FILESYSTEM_H
#define FILESYSTEM_H
#include <string>
#include <iostream>
class Directory;

using namespace std;

class FileSystem
{
    friend class Directory;
    public:

        FileSystem(const string  &_name) ;
        virtual ~FileSystem();
        string get_name() const;// la fonction est une fonction � en lecture seule �
        Directory *get_root() const;
    protected:

    private:
        string name;
        Directory *root;
        static int get_fresh_uid();
        static int identifier;

        //int uid;

};

std::ostream& operator <<( ostream& out , FileSystem &fs);
#endif // FILESYSTEM_H
