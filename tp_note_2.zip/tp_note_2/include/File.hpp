#ifndef FILE_HPP
#define FILE_HPP
#include <string>
#include "Node.hpp"
#include <iostream>
using namespace std;

class File : public Node
{
       friend class Directory;
    public:

           bool is_directory();
           Directory *to_directory();
           File *to_File();
           int size();
           string get_content() const;
           void set_content(const string&);//lors de passe par reference il faut tjr maittre const
           virtual void print_to(ostream & out, const int &n);

    protected:

    private:
          string content;
          File(FileSystem *_fs,const int &_uid,const string &_name ,Directory  *_parent = nullptr);
          virtual ~File();
};

#endif // FILE_HPP
